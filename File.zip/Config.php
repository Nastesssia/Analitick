<?php

/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "u2615238_Alex");
define("DB_PASSWORD", "zO0oO9iA4mcB1fZ9");
define("DB_DATABASE", "u2615238_Analitik");
?>
